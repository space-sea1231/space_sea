#include "testlib.h"

#include <algorithm>
#include <array>
#include <vector>

struct TaoChecker {
    int n, k, lg;
    std::vector<int> depth;
    std::vector<std::vector<int>> up;
    std::vector<int> a, b;

    int lca(int x, int y) const {
        if (depth[x] < depth[y]) std::swap(x, y);
        int d = depth[x] - depth[y];
        for (int j = 0; d; ++j, d >>= 1) if (d & 1) x = up[j][x];
        if (x == y) return x;
        for (int j = lg - 1; j >= 0; --j)
            if (up[j][x] != up[j][y]) x = up[j][x], y = up[j][y];
        return up[0][x];
    }

    int distance(int x, int y) const {
        const int z = lca(x, y);
        return depth[x] + depth[y] - 2 * depth[z];
    }

    int overlap(int id1, int id2) const {
        const std::array<int, 4> e = {a[id1], b[id1], a[id2], b[id2]};
        std::vector<int> cand(e.begin(), e.end());
        for (int i = 0; i < 4; ++i)
            for (int j = i + 1; j < 4; ++j)
                cand.push_back(lca(e[i], e[j]));
        int ans = 0;
        const int len1 = distance(a[id1], b[id1]);
        const int len2 = distance(a[id2], b[id2]);
        for (int x : cand) {
            if (distance(a[id1], x) + distance(x, b[id1]) != len1) continue;
            if (distance(a[id2], x) + distance(x, b[id2]) != len2) continue;
            for (int y : cand) {
                if (distance(a[id1], y) + distance(y, b[id1]) != len1) continue;
                if (distance(a[id2], y) + distance(y, b[id2]) != len2) continue;
                ans = std::max(ans, distance(x, y));
            }
        }
        return ans;
    }

    void readInput(InStream &in) {
        n = in.readInt(2, 200000);
        k = in.readInt(2, 200000);
        std::vector<int> parent(n + 1, 0);
        for (int i = 2; i <= n; ++i) parent[i] = in.readInt(1, i - 1);
        depth.assign(n + 1, 0);
        for (int i = 2; i <= n; ++i) depth[i] = depth[parent[i]] + 1;
        lg = 1;
        while ((1 << lg) <= n) ++lg;
        up.assign(lg, std::vector<int>(n + 1, 1));
        for (int i = 1; i <= n; ++i) up[0][i] = (i == 1 ? 1 : parent[i]);
        for (int j = 1; j < lg; ++j)
            for (int i = 1; i <= n; ++i) up[j][i] = up[j - 1][up[j - 1][i]];
        a.assign(k + 1, 0);
        b.assign(k + 1, 0);
        for (int i = 1; i <= k; ++i) {
            a[i] = in.readInt(1, n);
            b[i] = in.readInt(1, n);
            if (a[i] == b[i]) quitf(_fail, "invalid jury input: equal endpoints");
        }
    }
};

int main(int argc, char *argv[]) {
    registerTestlibCmd(argc, argv);
    TaoChecker c;
    c.readInput(inf);

    const int juryValue = ans.readInt();
    const int juryId1 = ans.readInt(1, c.k);
    const int juryId2 = ans.readInt(1, c.k);
    ans.skipBlanks();
    ans.readEof();
    if (juryId1 == juryId2) quitf(_fail, "jury output uses equal path ids");
    const int juryActual = c.overlap(juryId1, juryId2);
    if (juryValue != juryActual)
        quitf(_fail, "jury output inconsistent: value=%d, actual=%d", juryValue, juryActual);

    const int outValue = ouf.readInt();
    const int outId1 = ouf.readInt(1, c.k);
    const int outId2 = ouf.readInt(1, c.k);
    ouf.skipBlanks();
    ouf.readEof();
    if (outId1 == outId2) quitf(_wa, "path ids must be different");
    if (outValue != juryValue) quitf(_wa, "reported value is not optimal");
    const int actual = c.overlap(outId1, outId2);
    if (actual != outValue)
        quitf(_wa, "reported pair has overlap %d, not %d", actual, outValue);
    quitf(_ok, "valid optimal pair");
}
